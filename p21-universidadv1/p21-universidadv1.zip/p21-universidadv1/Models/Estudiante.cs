using System;
 
namespace p21_universidadv1.Modelo
{
    public class Estudiante : Persona {
        public DateTime fechadeingreso {get; set;}
    }
}