using System;
using System.ComponentModel.DataAnnotations;
namespace p21_universidadv1.Modelo
{
    public class Departamento {
        [Key]
        public int departamentoid {get; set;}
        public string nombre {get; set;}
        public float presupuesto {get; set;}
        public DateTime fechadeinicio {get; set;}
        public int instructorid {get; set;}
    }
}