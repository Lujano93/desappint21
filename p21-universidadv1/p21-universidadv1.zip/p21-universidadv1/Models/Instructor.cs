using System;

namespace p21_universidadv1.Modelo
{
    public class Instructor : Persona {
        public DateTime fechacontratacion {get; set;}
    }
}